# Running the CCPP automated tests

1. Place the original `Folds5x2_pp.ods` dataset in `data/`.
2. Install `pytest pandas odfpy numpy scikit-learn`.
3. From the repository root, run `python -m pytest -v tests/test_ccpp.py`.
4. View `tests/test_report.html` for the recorded run.

The suite covers 11 automated checks. It does not execute the entire Colab notebook or independently validate every figure and engineering interpretation.
