"""Automated checks for the MMA3001 CCPP analysis notebook."""
import ast
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, train_test_split

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "Folds5x2_pp.ods"
NOTEBOOK = ROOT / "notebooks" / "CCPP_analysis.ipynb"
FEATURES = ["AT", "V", "AP", "RH"]
TARGET = "PE"
SEED = 42

@pytest.fixture(scope="session")
def sheets():
    assert DATA.is_file(), "Copy Folds5x2_pp.ods into data/ before running pytest"
    return pd.read_excel(DATA, sheet_name=None, engine="odf")

@pytest.fixture(scope="session")
def df(sheets):
    return sheets["Sheet1"]

@pytest.fixture(scope="session")
def notebook():
    return json.loads(NOTEBOOK.read_text(encoding="utf-8"))


def test_notebook_json_and_python_syntax(notebook):
    assert notebook["cells"]
    for index, cell in enumerate(notebook["cells"]):
        if cell["cell_type"] != "code":
            continue
        source = "".join(cell["source"])
        source = "\n".join(line for line in source.splitlines() if not line.lstrip().startswith(("%", "!")))
        compile(source, f"cell_{index}", "exec")


def test_five_sheets_have_expected_shape_and_columns(sheets):
    assert len(sheets) == 5
    for sheet in sheets.values():
        assert sheet.shape == (9568, 5)
        assert list(sheet.columns) == FEATURES + [TARGET]


def test_data_is_finite_and_numeric(sheets):
    for sheet in sheets.values():
        assert all(pd.api.types.is_numeric_dtype(sheet[col]) for col in FEATURES + [TARGET])
        assert np.isfinite(sheet.to_numpy()).all()


def test_sheets_are_same_records_in_different_orders(sheets, df):
    reference = df.value_counts(dropna=False).sort_index()
    for sheet in sheets.values():
        pd.testing.assert_series_equal(sheet.value_counts(dropna=False).sort_index(), reference)


def test_data_ranges_and_duplicate_count(df):
    assert df.duplicated().sum() == 41
    assert df["RH"].max() > 100  # Retain source measurements; don't silently clamp.
    assert df["PE"].between(400, 510).all()


def test_split_sizes_and_reproducibility(df):
    indices = np.arange(len(df))
    a_train, a_test = train_test_split(indices, test_size=0.2, random_state=SEED)
    b_train, b_test = train_test_split(indices, test_size=0.2, random_state=SEED)
    assert len(a_train) == 7654 and len(a_test) == 1914
    assert not set(a_train).intersection(a_test)
    np.testing.assert_array_equal(a_train, b_train)
    np.testing.assert_array_equal(a_test, b_test)


def test_cross_validation_partitions_training_set(df):
    train_ids, _ = train_test_split(np.arange(len(df)), test_size=0.2, random_state=SEED)
    cv = KFold(n_splits=5, shuffle=True, random_state=SEED)
    validation_indices = []
    for tr, val in cv.split(train_ids):
        assert not set(tr).intersection(val)
        validation_indices.extend(val.tolist())
    assert sorted(validation_indices) == list(range(len(train_ids)))


def test_metric_function_known_values(notebook):
    sources = ["".join(c["source"]) for c in notebook["cells"] if c["cell_type"] == "code"]
    functions = [node for source in sources for node in ast.parse("\n".join(l for l in source.splitlines() if not l.lstrip().startswith("%"))).body if isinstance(node, ast.FunctionDef) and node.name == "metrics"]
    assert len(functions) == 1
    namespace = {"mean_absolute_error": mean_absolute_error, "mean_squared_error": mean_squared_error, "r2_score": r2_score, "np": np}
    exec(compile(ast.Module(body=[functions[0]], type_ignores=[]), "metrics", "exec"), namespace)
    result = namespace["metrics"]([1, 2, 3], [1, 3, 2])
    assert result["MAE_MW"] == pytest.approx(2 / 3)
    assert result["RMSE_MW"] == pytest.approx(np.sqrt(2 / 3))
    assert result["R2"] == pytest.approx(0)


def test_mean_baseline_matches_training_mean(df):
    xtr, xte, ytr, yte = train_test_split(df[FEATURES], df[TARGET], test_size=0.2, random_state=SEED)
    model = DummyRegressor(strategy="mean").fit(xtr, ytr)
    np.testing.assert_allclose(model.predict(xte[:10]), ytr.mean())


def test_histogram_boosting_predicts_finite_values(df):
    xtr, xte, ytr, yte = train_test_split(df[FEATURES], df[TARGET], test_size=0.2, random_state=SEED)
    model = HistGradientBoostingRegressor(max_iter=200, learning_rate=0.1, random_state=SEED)
    model.fit(xtr, ytr)
    predictions = model.predict(xte)
    assert predictions.shape == (1914,)
    assert np.isfinite(predictions).all()
    assert np.sqrt(mean_squared_error(yte, predictions)) < 4.0
    assert r2_score(yte, predictions) > 0.95


def test_bootstrap_indices_are_valid_and_seeded(df):
    n = 1914
    first = np.random.default_rng(SEED).integers(0, n, n)
    second = np.random.default_rng(SEED).integers(0, n, n)
    np.testing.assert_array_equal(first, second)
    assert first.min() >= 0 and first.max() < n
